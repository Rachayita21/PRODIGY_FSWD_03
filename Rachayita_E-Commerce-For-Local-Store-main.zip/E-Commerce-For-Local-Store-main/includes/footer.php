<div class="footer">
    <div class="page-container footer-container">
        <div class="footer-copyright"><h4>© 2024 Copyright Sri-Krishna Stores</h4> 
        <h5>Created & Run By Pranava Aithal K</h5>
    <a href="https://www.linkedin.com/in/pranava-aithal-k-b8591a24a" target="_blank" ><img style="width:10%;height:10%;" src="img/linkedin.png"></a>
    </div>
    </div>
   
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
